# 🗝️ AI-Escape-Room

An LLM-powered text escape room built with **Python, Streamlit and the Google Gemini API**.
You wake up in a locked library and must explore, find clues and solve puzzles to open the door.

The project has two versions that show how to move from a *fun prototype* to a *reliable LLM application*:

| | **Version 1** (`v1/`) | **Version 2** (`v2/`) |
|---|---|---|
| Who decides if an action works? | The LLM | **Python rules engine** |
| Where is the game state? | Chat history only | **Structured JSON state** |
| Where are the solutions? | Inside the LLM prompt | **Config file, never sent to the LLM** |
| Role of the LLM | Everything | Understand intent + narrate results |
| Handles cheating / injection | No | **Yes** (filter, validation, output guard) |

## The game
Objects: desk, bookshelf (+ four red books), painting, locked drawer, door.
Puzzles: **(1)** books reveal the drawer code → **(2)** drawer holds a UV flashlight → **(3)** flashlight reveals the door code on the painting → **escape**.
Items: torn note, UV flashlight.

## Install & run
```bash
git clone https://github.com/<your-username>/AI-Escape-Room.git
cd AI-Escape-Room
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt

cp .env.example .env        # then paste your free key from https://aistudio.google.com/apikey

streamlit run v1/app.py     # Version 1
streamlit run v2/app.py     # Version 2
pytest -v                   # offline tests for Version 2 (no API key needed)
```
Version 2 also runs **without** an API key (offline mode: rule-based parser and plain text), which is how the tests run.

## Architecture

### Version 1
```mermaid
flowchart LR
    P[Player] -->|natural language| UI[Streamlit UI]
    UI -->|full chat history| LLM[Gemini<br/>Game Master]
    SP[System prompt<br/>room + puzzles + SOLUTIONS] --> LLM
    LLM -->|story text, rules, state,<br/>win detection| UI
    UI --> P
```
Everything (rules, state, win condition) is delegated to the LLM; the only memory is the chat log.

### Version 2
```mermaid
flowchart LR
    P[Player] -->|text| UI[Streamlit UI]
    UI --> F{Security<br/>pre-filter}
    F -->|attack / admin / secrets| R[Fixed refusal]
    F -->|ok| IP[Intent parser<br/>Gemini JSON, regex fallback]
    IP -->|action, target, item, code| E[Rules Engine<br/>validation]
    CFG[(game_config.json<br/>objects, items, codes, rules)] --> E
    E <-->|read / update| S[(Game state<br/>inventory, flags, attempts)]
    E -->|result: ok, event, facts| N[Narrator<br/>Gemini]
    N --> G{Output guard<br/>no undiscovered codes}
    G -->|safe| UI
    G -->|leak| FB[Plain engine facts] --> UI
    R --> UI
    UI --> P
```
Key idea: **the LLM never sees undiscovered secrets and never decides outcomes.** The engine returns facts; the LLM only phrases them.

## Repository layout
```
v1/app.py                 Version 1 (LLM does everything)
v2/engine.py              State, validators, rules (the source of truth)
v2/intent.py              Security filter, intent parsing, narration + output guard
v2/llm.py                 Gemini wrapper
v2/app.py                 Streamlit UI (inventory, progress, restart, debug view)
v2/game_config.json       Room, items, codes, hints
tests/test_v2_engine.py   13 offline tests
docs/TEST_CASES.md        V1 vs V2 test cases
REPORT.md                 Short project report
```

## Tests
See [`docs/TEST_CASES.md`](docs/TEST_CASES.md) for the six adversarial/robustness cases and how V1 and V2 differ. Screenshots go in `docs/screenshots/`.

## Limitations / future work
- The rule-based fallback parser is keyword-based; the LLM parser handles unusual phrasing better.
- Narration quality depends on the model; the output guard falls back to plain text if a secret leaks.
- Single room, single-player, no persistence across browser sessions.
- Ideas: multiple rooms, a timer, saved games, a stronger semantic output check.

## Security
API keys are read from environment variables (`.env`, git-ignored). Never commit `.env`.
