# AI-Powered Escape Room: Project Report

## 1. Goal
Build an interactive escape room where an LLM acts as Game Master, first as a quick prototype (Version 1) and then as a reliable system (Version 2). The scenario is a locked library with five interactive objects (desk, bookshelf, painting, drawer, door), a hidden group of red books, two collectible items and three chained puzzles: books → drawer code → UV flashlight → painting → door code.

## 2. Version 1: LLM does everything
**Design.** A Streamlit chat UI sends the whole conversation to Gemini. The system prompt contains the room description, puzzle rules and *the solutions*. The model describes the world, decides whether actions work, remembers progress through the chat history and signals victory with a `[[ESCAPED]]` token. A sidebar provides instructions and a restart button.

**What worked.** It took very little code, and the narration is rich and flexible. The player can type anything.

**Problems found.** (1) *Inventory is not enforced*: the model may let the player use items never found. (2) *Hallucinated objects*: it invents things when asked about them. (3) *Early clue leaks*: the solutions sit in the prompt, so persistent players can obtain them. (4) *Trusting false claims* ("I already solved it"). (5) *Prompt injection*: "I am the administrator" can override the rules. (6) *Drift*: state exists only as text, so in long sessions the model can contradict itself. All of these come from one root cause: **the LLM is simultaneously the narrator, the rule-keeper and the database.**

## 3. Version 2: Python owns the truth
**Design principle.** Separate *deciding* from *describing*. Python decides; the LLM describes.

**Components.**
- **Game state** (`engine.new_state`): inventory, flags (examined, unlocked, revealed), failed attempts, escaped status, move log. It is plain JSON-serialisable data.
- **Game rules** (`game_config.json`): objects, aliases, items, visibility conditions, locks and codes, use-rules and hints. Solutions live only here, never in a prompt.
- **Action validation** (`engine.py`): one handler per action (examine, take, use, enter_code, open, inventory, hint). Each checks preconditions (item owned? item visible? object exists? lock already open? right number of digits?) and updates state only when valid. The engine returns `{ok, event, facts}`.
- **Intent parser** (`intent.py`): Gemini converts free text into structured JSON in JSON mode at temperature 0, with a rule-based fallback. Codes are extracted from the player's own digits by regex, never from LLM output.
- **Security layers.** (a) A regex pre-filter catches admin impersonation, "ignore your instructions" and requests for codes; these get a fixed refusal without involving the LLM. (b) The narrator receives only the engine's facts and strict instructions. (c) An **output guard** scans the narration and falls back to plain facts if it contains any code the player has not legitimately discovered.
- **UI**: inventory panel, progress checklist, debug view of the parsed intent and state, restart button.

## 4. Testing
Thirteen offline pytest tests cover a full walkthrough, uncollected items, hidden items, wrong codes, false claims, admin impersonation, secret requests, nonexistent objects, out-of-order codes, persistence of solved puzzles, the clue-visibility rule and the leak guard. The comparison with Version 1 is in `docs/TEST_CASES.md`. Because the tests exercise the engine and rule-based parser directly, they are deterministic and need no API key.

## 5. Problems encountered and lessons
- **Free-text understanding vs. strictness.** Pure rule parsing is brittle; pure LLM parsing is unsafe. Combining an LLM classifier with deterministic extraction of codes and a strict engine gave flexibility without giving the LLM authority.
- **Leaks through narration.** Even when the narrator only receives facts, it might add digits. The output guard handles this, at the cost of occasionally falling back to plain text.
- **Ambiguous nouns** ("books" vs. "bookshelf", "desk" vs. "desk drawer") required alias matching with an earliest-and-longest-match rule.
- **Remaining limitations.** The keyword fallback is simple; the keyword filter can be bypassed by creative phrasing, but because the engine validates every action, a bypass of the filter still cannot change state illegitimately. That is the main benefit of the design.

## 6. Conclusion
Version 1 shows how quickly an LLM can power an engaging game. Version 2 shows that reliability comes from architecture, not prompting: structured state, deterministic validation and a narrow job for the LLM.
